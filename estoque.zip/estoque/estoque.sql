-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 19-Fev-2026 às 00:39
-- Versão do servidor: 10.1.38-MariaDB
-- versão do PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `estoque`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `categoria`
--

CREATE TABLE `categoria` (
  `id` int(11) NOT NULL,
  `categoria` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `categoria`
--

INSERT INTO `categoria` (`id`, `categoria`) VALUES
(23, 'OUTROS'),
(24, 'CAPACITOR CERAMICO'),
(25, 'CAPACITOR ELETROLÃTICO'),
(27, 'RESISTOR DE FIO'),
(28, 'TRANSFORMADOR'),
(29, 'INDUTOR'),
(30, 'VARISTOR'),
(31, 'CIRCUITO INTEGRADO'),
(33, 'RESISTOR 1/4W'),
(34, 'FERRO DE SOLDA'),
(35, 'FLYBACK'),
(37, 'TRANSISTOR'),
(38, 'DIODO ZENER'),
(40, 'RESISTOR 1/2WSS'),
(41, 'CAPACITOS 1,56');

-- --------------------------------------------------------

--
-- Estrutura da tabela `produtos`
--

CREATE TABLE `produtos` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `data_entrada` date NOT NULL,
  `dataReposicao` date NOT NULL,
  `data_saida` date NOT NULL,
  `codigo_barras` varchar(100) NOT NULL,
  `preco_custo` decimal(10,2) NOT NULL,
  `preco_venda` decimal(10,2) NOT NULL,
  `quantidade_inicial` int(11) NOT NULL,
  `quantidade` int(11) NOT NULL,
  `categoria` varchar(100) NOT NULL,
  `fabricante` varchar(100) NOT NULL,
  `prateleira` varchar(100) NOT NULL,
  `outros` varchar(100) NOT NULL,
  `fornecedor` varchar(100) NOT NULL,
  `endereco` varchar(100) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `obs` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `produtos`
--

INSERT INTO `produtos` (`id`, `nome`, `data_entrada`, `dataReposicao`, `data_saida`, `codigo_barras`, `preco_custo`, `preco_venda`, `quantidade_inicial`, `quantidade`, `categoria`, `fabricante`, `prateleira`, `outros`, `fornecedor`, `endereco`, `telefone`, `email`, `obs`) VALUES
(7, 'BC548B', '2026-02-15', '2026-02-17', '2026-02-17', '1234567890', '1.95', '4.56', 15, 13, 'CAPACITOS 1,56', '', '', '', '', '', '', '', ''),
(8, 'TESTE JAVASCRIPT', '2023-10-19', '0000-00-00', '0000-00-00', '12323232', '2.25', '4.90', 12, 23, 'RESISTOR 1/2WSS', 'TC CLAUDIO', 'A10', 'TESTE OUTROS', 'JOAO DA MATA', 'RUA DA PRAIA 1234', '(81) 99934-2344', 'joao@bol.com.br', ''),
(9, 'TDA2002', '2026-02-17', '0000-00-00', '0000-00-00', '12323232', '0.00', '0.00', 12, 12, 'RESISTOR 1/2WSS', '', '', '', '', '', '', '', ''),
(12, 'TESTE COMPLETO', '2026-02-17', '0000-00-00', '0000-00-00', '12323232', '2.25', '4.90', 33, 33, 'RESISTOR 1/2WSS', 'TC CLAUDIO', 'AA33', 'TESTE OUTROS', 'JOAO DA MATA', 'RUA DA PRAIA 1234', '(81) 99934-2344', 'joao@bol.com.br', 'TUDO OK'),
(13, 'TESTE RAPIDO', '2026-02-17', '0000-00-00', '0000-00-00', '12323232', '2.25', '4.90', 33, 33, 'CAPACITOS 1,56', 'TC CLAUDIO', 'AA33', 'TESTE OUTROS', 'JOAO DA MATA SILVA', 'RUA DA PRAIA 144', '(81) 99934-2344', 'joao@bol.com.br', 'NENHUMA'),
(14, 'TESTE COMPLETOS', '2026-02-17', '0000-00-00', '2026-02-17', '12323232', '2.25', '4.90', 33, 30, 'TRANSISTOR', 'TC CLAUDIO', 'AA33', 'TESTE OUTROS', 'JOAO DA MATA SILVA', 'RUA DA PRAIA 144', '(81) 99934-2344', 'joao@bol.com.br', ''),
(15, 'TESTE COMPLETOSSA', '2026-02-17', '0000-00-00', '0000-00-00', '12323232', '2.25', '4.90', 33, 33, 'FERRO DE SOLDA', 'TC CLAUDIO', 'AA33', 'TESTE OUTROS', 'JOAO DA MATA SILVA', 'RUA DA PRAIA 144', '(81) 99934-2344', 'joao@bol.com.br', ''),
(16, 'TESTE COMP', '2026-02-17', '0000-00-00', '0000-00-00', '12323232', '2.25', '4.90', 33, 33, 'CAPACITOS 1,56', 'TC CLAUDIO', 'AA33', 'TESTE OUTROS', 'JOAO DA MATA SILVA', 'RUA DA PRAIA 144', '(81) 99934-2344', 'joao@bol.com.br', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categoria`
--
ALTER TABLE `categoria`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `produtos`
--
ALTER TABLE `produtos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categoria`
--
ALTER TABLE `categoria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `produtos`
--
ALTER TABLE `produtos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
